module.exports = url = {
    public_report_api: 'https://api.cowin.gov.in/api/v1/reports/v2/getPublicReports?state_id=&district_id=&date'
}

