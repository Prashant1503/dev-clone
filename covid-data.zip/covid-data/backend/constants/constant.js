exports.urls = {
    countryUrl: 'https://api.rootnet.in/covid19-in/stats/latest',
    districtUrl: 'https://api.covid19india.org/state_district_wise.json'
}